---
name: Expenzo Lumina
colors:
  surface: '#11131c'
  surface-dim: '#11131c'
  surface-bright: '#373943'
  surface-container-lowest: '#0c0e17'
  surface-container-low: '#191b25'
  surface-container: '#1d1f29'
  surface-container-high: '#282933'
  surface-container-highest: '#32343f'
  on-surface: '#e1e1ef'
  on-surface-variant: '#cfc2d6'
  inverse-surface: '#e1e1ef'
  inverse-on-surface: '#2e303a'
  outline: '#988d9f'
  outline-variant: '#4d4354'
  surface-tint: '#ddb7ff'
  primary: '#ddb7ff'
  on-primary: '#490080'
  primary-container: '#b76dff'
  on-primary-container: '#400071'
  inverse-primary: '#842bd2'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#d2bfe8'
  on-tertiary: '#382a4a'
  tertiary-container: '#9b8ab0'
  on-tertiary-container: '#312343'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#f0dbff'
  primary-fixed-dim: '#ddb7ff'
  on-primary-fixed: '#2c0051'
  on-primary-fixed-variant: '#6900b3'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#eddcff'
  tertiary-fixed-dim: '#d2bfe8'
  on-tertiary-fixed: '#221534'
  on-tertiary-fixed-variant: '#4f4062'
  background: '#11131c'
  on-background: '#e1e1ef'
  surface-variant: '#32343f'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 38px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  mono-numeric:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies high-velocity financial intelligence with an atmosphere of nocturnal precision, privacy, and refined technological luxury. Designed for high-net-worth operators, tech founders, and contemporary digital-first consumers, it balances the calculated rigor of modern fintech with tactile, luminous elegance.

The visual signature merges **Atmospheric Glassmorphism** with **Deep Tonal Elevation**:
- **Atmospheric & Immersive:** Midnight navy-blacks form a calm, low-glare canvas that reduces cognitive friction during complex balance monitoring and cash-flow audits.
- **Luminescent Hierarchy:** Purple-to-lavender primary accents paired with diffused specular highlights establish immediate interaction clarity.
- **Positive Velocity:** Precision emerald green highlights signify dynamic financial velocity, secure encryption states, and asset accrual.
- **Restraint & Polish:** Micro-borders with low-alpha violet tinting replace opaque structural lines, creating crisp separation without visual clutter.

## Colors

The palette leverages pure deep-space darks layered with spectral purple lighting and acute emerald indicators.

### Palette Architecture
- **Primary Accents (`#8B5CF6`, `#A855F7`, `#C084FC`):** Direct action items, active navigational indicators, primary interactive buttons, and volumetric glows.
- **Secondary Accents (`#10B981`, `#34D399`):** Financial positive deltas, yield increases, encryption verifications, successful ledger reconciliation, and confirmed transfer badges.
- **Tertiary Accent (`#E9D5FF`):** Soft lavender specular highlights, active metric readout accents, and pill glow halos.
- **Surface Architecture:**
  - `Base Canvas`: `#090B14` (Deep midnight black)
  - `Surface Container Low`: `#0E1326` (Midnight navy tier 1)
  - `Surface Container Mid`: `#141933` (Elevated navy tier 2)
  - `Surface Glass High`: `rgba(20, 25, 51, 0.65)` with backdrop-filter blur.
- **Borders & Dividers:** `rgba(139, 92, 246, 0.15)` for cards and table rows; `rgba(168, 85, 247, 0.35)` on interactive hover states.
- **Neutral Typographic Palette:**
  - High Contrast / Primary: `#F8FAFC` (Pure balance readouts and headers)
  - Medium Contrast / Secondary: `#94A3B8` (Metadata, input labels, transaction dates)
  - Low Contrast / Tertiary: `#64748B` (Inactive states, table headers, breadcrumbs)

## Typography

Typographic hierarchy relies solely on **Plus Jakarta Sans**, utilizing its geometric clarity, humanist open counters, and structured weights to present financial analytics cleanly.

### Typographic Rules
- **Tabular Numerics:** All currency figures, ledger numbers, card numbers, and percentage readouts must use `font-feature-settings: "tnum" 1, "cv05" 1` to prevent horizontal jitter during real-time balance streaming.
- **Display Weights:** Heavy weights (700 and 800) are reserved strictly for high-level asset balances and primary stage titles.
- **Label Tracking:** Small labels (11px–12px) use increased letter spacing (+0.02em to +0.04em) in uppercase to guarantee high readability against dark surfaces.

## Layout & Spacing

The layout structure balances strict metric alignment with generous negative space.

### Grid Infrastructure
- **Desktop (1024px+):** 12-column fluid grid, `2rem` outer margins, `1.5rem` gutters. Max container constrained to `1440px`.
- **Tablet (768px – 1023px):** 8-column fluid grid, `1.5rem` margins, `1rem` gutters. Sidebar navigations compress to icon-only rails.
- **Mobile (< 768px):** 4-column fluid layout, `1rem` safe margins, `1rem` gutters. Multi-metric dashboard panels collapse into vertical single-column cards with edge-to-edge swipe carousels for horizontal transaction lists.

### Internal Spacing Rhythm
- Density scales through an 8-point harmonic base. Gaps between compact transaction items rely on `space-xs` and `space-sm`, while section separations use `space-xl`.

## Elevation & Depth

Visual hierarchy uses frosted optical depth, translucent tinted planes, and soft multi-stop violet ambient glows rather than opaque drop shadows.

### Atmospheric Tiering
1. **Canvas (Base Level):** Raw background `#090B14`. Non-interactive backdrop.
2. **Surface Tier 1 (Cards, Modules):** Background `#0E1326` at 80% opacity, bordered by `1px solid rgba(139, 92, 246, 0.15)`. Backdrop blur `16px`.
3. **Surface Tier 2 (Floating Modals, Flyouts, Active Dropdowns):** Background `#141933` at 90% opacity, bordered by `1px solid rgba(168, 85, 247, 0.3)`. Backdrop blur `24px`. Shadow: `0 20px 40px -15px rgba(0, 0, 0, 0.7), 0 0 20px 0 rgba(139, 92, 246, 0.12)`.
4. **Primary Active Glow:** Hovered actionable items or primary CTA triggers produce a diffuse micro-shadow: `0 0 24px rgba(168, 85, 247, 0.45)`.
5. **Positive Accrual Glow:** Dynamic velocity tags emit a directional soft emerald radiance: `0 0 16px rgba(16, 185, 129, 0.3)`.

## Shapes

The design system employs **Level 2 (Rounded)** architecture to combine architectural discipline with approachable, tactile surfaces.

### Corner Rules
- Standard interactive elements (buttons, inputs, dropdown selectors): `0.5rem` (`rounded-md`).
- Primary content containers, analytical cards, modal sheets: `1rem` (`rounded-lg`).
- Feature hero cards and elevated telemetry containers: `1.5rem` (`rounded-xl`).
- Status pills, avatars, security badges, tags: Full continuous roundedness (`9999px`).

## Components

### Buttons
- **Primary Action:** Solid gradient background from `#8B5CF6` to `#A855F7`. Text `#F8FAFC`, weight 600. Subtle inner white highlight on the top edge (`inset 0 1px 0 rgba(255, 255, 255, 0.2)`). Box shadow: `0 4px 14px rgba(139, 92, 246, 0.35)`. Hover enhances blur to `0 6px 20px rgba(168, 85, 247, 0.5)`.
- **Secondary (Glass):** Background `rgba(20, 25, 51, 0.8)`, border `1px solid rgba(139, 92, 246, 0.2)`. Text `#E9D5FF`. On hover: border switches to `rgba(192, 132, 252, 0.5)` with background `rgba(20, 25, 51, 1)`.
- **Ghost:** Background transparent, text `#94A3B8`. Hover text `#F8FAFC`, background `rgba(139, 92, 246, 0.08)`.

### Cards & Analytical Panels
- Layered with `rgba(14, 19, 38, 0.7)` backdrop, `16px` blur filter, and continuous border `1px solid rgba(139, 92, 246, 0.15)`.
- Header bars within cards maintain a separation line of `1px solid rgba(139, 92, 246, 0.08)`.
- Interactive state (e.g., selectable bank account card): Top edge receives a subtle radial spotlight gradient mask.

### Input Fields & Selectors
- Background `rgba(9, 11, 20, 0.7)`. Border `1px solid rgba(139, 92, 246, 0.2)`. Height 44px, text `#F8FAFC`.
- Focus state: Border transitions to `#A855F7` with an ambient glow of `0 0 0 3px rgba(168, 85, 247, 0.2)`.
- Placeholder color: `#64748B`.

### Financial Metric Badges & Velocity Chips
- **Positive Velocity Tag:** Pill shape (`9999px`). Background `rgba(16, 185, 129, 0.12)`, border `1px solid rgba(16, 185, 129, 0.35)`. Text `#34D399`, font size `12px`, weight 700. Prepended by a geometric upward micro-arrow.
- **Security & Encryption Chip:** Pill shape. Background `rgba(139, 92, 246, 0.1)`, border `1px solid rgba(139, 92, 246, 0.25)`. Text `#E9D5FF`. Accompanied by a pulsating 6px dot indicator in `#C084FC`.

### Selection Controls (Checkboxes & Radios)
- Checkbox: Base `18px × 18px`, radius `4px`. Background `#0E1326`, border `1px solid rgba(139, 92, 246, 0.3)`. Checked state: Background `#A855F7` with crisp white checkmark icon.
- Radio: Radius `50%`. Checked state reveals an inner dot in `#E9D5FF` backed by `#8B5CF6`.

### Transaction Lists & Data Rows
- Row padding: `12px 16px`. Hover background tint `rgba(139, 92, 246, 0.04)`.
- Bottom border: `1px solid rgba(255, 255, 255, 0.03)`.
- Numeric column aligned strictly right using tabular numbers (`mono-numeric`). Positive inflows rendered in `#34D399`; standard debits in `#F8FAFC`.